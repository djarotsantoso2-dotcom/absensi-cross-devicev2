PATCH RADIUS ABSENSI 50 METER

Perubahan:
- Kebandungan: 10 m -> 50 m
- Nanas: 10 m -> 50 m

Titik tetap:
- Kebandungan: -6.633483, 106.775966
- Nanas: -6.618490474658237, 106.78478377021241

Tidak berubah:
- Parakan
- CM
- v1.9.9
- database
- lembur
- jadwal
- fitur lain

Cara pakai:
1. Upload ZIP ini ke root Codespaces.
2. Jalankan:
   unzip -o "Absensi_Radius_KBDG_NANAS_50M.zip"
   python3 apply_radius_50m.py
3. Jika semua validasi OK:
   git add web/config.js web/sw.js backend/Code.gs
   git commit -m "Expand Kebandungan and Nanas geofence to 50m"
   git push origin main
4. Setelah push, copy backend/Code.gs terbaru ke Google Apps Script lalu:
   Save -> Deploy -> Manage deployments -> Edit -> New version -> Deploy
