from pathlib import Path
import shutil

root = Path.cwd()
cfg = root / 'web' / 'config.js'
backend = root / 'backend' / 'Code.gs'
sw = root / 'web' / 'sw.js'

for p in (cfg, backend, sw):
    if not p.exists():
        raise SystemExit(f'ERROR: {p} tidak ditemukan. Jalankan dari root repo absensi-cross-devicev2.')

for p in (cfg, backend, sw):
    bak = p.with_suffix(p.suffix + '.bak-radius-50m')
    if not bak.exists():
        shutil.copy2(p, bak)

c = cfg.read_text(encoding='utf-8')
b = backend.read_text(encoding='utf-8')
s = sw.read_text(encoding='utf-8')

old = "KEBANDUNGAN: Object.freeze({NAME:'Kebandungan', LAT:-6.633483, LON:106.775966, RADIUS_M:10})"
new = "KEBANDUNGAN: Object.freeze({NAME:'Kebandungan', LAT:-6.633483, LON:106.775966, RADIUS_M:50})"
if new not in c:
    if old not in c:
        raise SystemExit('ERROR: baris Kebandungan frontend tidak ditemukan')
    c = c.replace(old, new, 1)

old = "NANAS: Object.freeze({NAME:'Nanas', LAT:-6.618490474658237, LON:106.78478377021241, RADIUS_M:10})"
new = "NANAS: Object.freeze({NAME:'Nanas', LAT:-6.618490474658237, LON:106.78478377021241, RADIUS_M:50})"
if new not in c:
    if old not in c:
        raise SystemExit('ERROR: baris Nanas frontend tidak ditemukan')
    c = c.replace(old, new, 1)

old = "KEBANDUNGAN: Object.freeze({name:'Kebandungan', lat:-6.633483, lon:106.775966, radiusM:10})"
new = "KEBANDUNGAN: Object.freeze({name:'Kebandungan', lat:-6.633483, lon:106.775966, radiusM:50})"
if new not in b:
    if old not in b:
        raise SystemExit('ERROR: baris Kebandungan backend tidak ditemukan')
    b = b.replace(old, new, 1)

old = "NANAS: Object.freeze({name:'Nanas', lat:-6.618490474658237, lon:106.78478377021241, radiusM:10})"
new = "NANAS: Object.freeze({name:'Nanas', lat:-6.618490474658237, lon:106.78478377021241, radiusM:50})"
if new not in b:
    if old not in b:
        raise SystemExit('ERROR: baris Nanas backend tidak ditemukan')
    b = b.replace(old, new, 1)

lines = s.splitlines()
if not lines or not lines[0].startswith('const CACHE = '):
    raise SystemExit('ERROR: CACHE service worker tidak ditemukan')
lines[0] = "const CACHE = 'absensi-gps-v1.9.9-kbdg-nanas-50m';"
s = '\n'.join(lines) + ('\n' if sw.read_text(encoding='utf-8').endswith('\n') else '')

checks = [
    ('frontend_kebandungan_50m', "RADIUS_M:50})" in c and "LAT:-6.633483, LON:106.775966" in c),
    ('frontend_nanas_50m', "LAT:-6.618490474658237, LON:106.78478377021241, RADIUS_M:50" in c),
    ('backend_kebandungan_50m', "lat:-6.633483, lon:106.775966, radiusM:50" in b),
    ('backend_nanas_50m', "lat:-6.618490474658237, lon:106.78478377021241, radiusM:50" in b),
    ('version_still_1_9_9', "APP_VERSION: '1.9.9'" in c and "const APP_VERSION = '1.9.9';" in b),
    ('cache_updated', 'absensi-gps-v1.9.9-kbdg-nanas-50m' in s),
]

for k, v in checks:
    print(('OK' if v else 'FAIL') + ' - ' + k)

if not all(v for _, v in checks):
    raise SystemExit('ERROR: validasi gagal. Jangan commit.')

cfg.write_text(c, encoding='utf-8')
backend.write_text(b, encoding='utf-8')
sw.write_text(s, encoding='utf-8')

print()
print('PATCH BERHASIL')
print('Kebandungan: radius 50 m')
print('Nanas: radius 50 m')
print('Parakan & CM: tidak berubah')
