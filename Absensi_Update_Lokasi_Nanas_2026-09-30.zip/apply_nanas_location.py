from pathlib import Path
import shutil

ROOT = Path.cwd()
CFG = ROOT / "web" / "config.js"
BACKEND = ROOT / "backend" / "Code.gs"
SW = ROOT / "web" / "sw.js"

for p in (CFG, BACKEND, SW):
    if not p.exists():
        raise SystemExit(f"ERROR: {p} tidak ditemukan. Jalankan dari root repo absensi-cross-devicev2.")

for p in (CFG, BACKEND, SW):
    bak = p.with_suffix(p.suffix + ".bak-nanas-20260930")
    if not bak.exists():
        shutil.copy2(p, bak)

cfg = CFG.read_text(encoding="utf-8")
backend = BACKEND.read_text(encoding="utf-8")
sw = SW.read_text(encoding="utf-8")

old_cfg = "NANAS: Object.freeze({NAME:'Nanas', LAT:-6.618239, LON:106.784676, RADIUS_M:10})"
new_cfg = "NANAS: Object.freeze({NAME:'Nanas', LAT:-6.618490474658237, LON:106.78478377021241, RADIUS_M:10})"

old_backend = "NANAS: Object.freeze({name:'Nanas', lat:-6.618239, lon:106.784676, radiusM:10})"
new_backend = "NANAS: Object.freeze({name:'Nanas', lat:-6.618490474658237, lon:106.78478377021241, radiusM:10})"

if new_cfg not in cfg:
    if old_cfg not in cfg:
        raise SystemExit("ERROR: koordinat Nanas lama tidak ditemukan di web/config.js")
    cfg = cfg.replace(old_cfg, new_cfg, 1)

if new_backend not in backend:
    if old_backend not in backend:
        raise SystemExit("ERROR: koordinat Nanas lama tidak ditemukan di backend/Code.gs")
    backend = backend.replace(old_backend, new_backend, 1)

lines = sw.splitlines()
if lines and lines[0].startswith("const CACHE = "):
    lines[0] = "const CACHE = 'absensi-gps-nanas-location-20260930';"
    sw = "\n".join(lines) + ("\n" if SW.read_text(encoding="utf-8").endswith("\n") else "")
else:
    raise SystemExit("ERROR: baris CACHE service worker tidak ditemukan")

CFG.write_text(cfg, encoding="utf-8")
BACKEND.write_text(backend, encoding="utf-8")
SW.write_text(sw, encoding="utf-8")

checks = {
    "frontend_nanas": "-6.618490474658237, LON:106.78478377021241" in cfg,
    "backend_nanas": "lat:-6.618490474658237, lon:106.78478377021241" in backend,
    "radius_10m_frontend": "RADIUS_M:10" in cfg,
    "radius_10m_backend": "radiusM:10" in backend,
    "cache_refreshed": "absensi-gps-nanas-location-20260930" in sw,
}

print("UPDATE LOKASI NANAS SELESAI DI FILE LOKAL")
for k,v in checks.items():
    print(f"{'OK' if v else 'FAIL'} - {k}")

if not all(checks.values()):
    raise SystemExit("ERROR: validasi gagal. Jangan commit.")

print()
print("Lokasi Nanas baru: -6.618490474658237, 106.78478377021241")
print("Radius tetap: 10 meter")
print()
print("Lanjutkan:")
print("git add web/config.js web/sw.js backend/Code.gs")
print('git commit -m "Update Nanas geofence location"')
print("git push origin main")
