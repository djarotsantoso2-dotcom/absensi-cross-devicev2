UPDATE LOKASI GUDANG NANAS
Tanggal: 30 September 2026

Titik lama:
-6.618239, 106.784676

Titik baru:
-6.618490474658237, 106.78478377021241

Radius geofence:
10 meter (tidak berubah)

File yang berubah:
- web/config.js
- backend/Code.gs
- web/sw.js (cache refresh saja)

Tidak mengubah:
- Kebandungan
- Parakan
- CM
- database absensi
- lembur
- jadwal kerja
- logo/menu

Cara pasang:
1. Upload ZIP ke root repo Codespaces.
2. Jalankan:
   unzip -o "Absensi_Update_Lokasi_Nanas_2026-09-30.zip"
   python3 apply_nanas_location.py
3. Jika semua validasi OK:
   git add web/config.js web/sw.js backend/Code.gs
   git commit -m "Update Nanas geofence location"
   git push origin main

PENTING:
Setelah push, backend/Code.gs terbaru WAJIB dicopy ke Google Apps Script lalu:
Deploy > Manage deployments > Edit > New version > Deploy

Ini wajib karena server juga memvalidasi geofence Nanas.
