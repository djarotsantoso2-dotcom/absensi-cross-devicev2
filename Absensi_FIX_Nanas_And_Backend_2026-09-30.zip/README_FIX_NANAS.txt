PATCH KOREKSI NANAS + BACKEND

Memperbaiki:
1. Typo backend `consta last = sh.getLastRow();` menjadi `const last = sh.getLastRow();`
2. Titik Nanas frontend menjadi -6.618490474658237, 106.78478377021241
3. Titik Nanas backend menjadi -6.618490474658237, 106.78478377021241
4. Radius tetap 10 meter
5. Refresh cache service worker

Jalankan:
unzip -o "Absensi_FIX_Nanas_And_Backend_2026-09-30.zip"
python3 apply_fix_nanas_backend.py
git add web/config.js web/sw.js backend/Code.gs
git commit -m "Fix Nanas geofence and backend syntax"
git push origin main

Setelah push berhasil, copy backend/Code.gs terbaru ke Google Apps Script lalu:
Save -> Deploy -> Manage deployments -> Edit -> New version -> Deploy
