from pathlib import Path
import shutil

root=Path.cwd()
cfg=root/'web'/'config.js'
be=root/'backend'/'Code.gs'
sw=root/'web'/'sw.js'

for p in (cfg,be,sw):
    if not p.exists():
        raise SystemExit(f'ERROR: {p} tidak ditemukan')

for p in (cfg,be,sw):
    bak=p.with_suffix(p.suffix+'.bak-fix-nanas-20260930')
    if not bak.exists():
        shutil.copy2(p,bak)

c=cfg.read_text(encoding='utf-8')
b=be.read_text(encoding='utf-8')
s=sw.read_text(encoding='utf-8')

b=b.replace('consta last = sh.getLastRow();','const last = sh.getLastRow();')

oldc="NANAS: Object.freeze({NAME:'Nanas', LAT:-6.618239, LON:106.784676, RADIUS_M:10})"
newc="NANAS: Object.freeze({NAME:'Nanas', LAT:-6.618490474658237, LON:106.78478377021241, RADIUS_M:10})"
if newc not in c:
    if oldc not in c: raise SystemExit('ERROR: koordinat Nanas frontend lama tidak ditemukan')
    c=c.replace(oldc,newc,1)

oldb="NANAS: Object.freeze({name:'Nanas', lat:-6.618239, lon:106.784676, radiusM:10})"
newb="NANAS: Object.freeze({name:'Nanas', lat:-6.618490474658237, lon:106.78478377021241, radiusM:10})"
if newb not in b:
    if oldb not in b: raise SystemExit('ERROR: koordinat Nanas backend lama tidak ditemukan')
    b=b.replace(oldb,newb,1)

lines=s.splitlines()
if not lines or not lines[0].startswith('const CACHE = '):
    raise SystemExit('ERROR: CACHE service worker tidak ditemukan')
lines[0]="const CACHE = 'absensi-gps-nanas-location-fix-20260930';"
s='\n'.join(lines)+('\n' if sw.read_text(encoding='utf-8').endswith('\n') else '')

checks=[
    ('backend_syntax_fixed','consta last' not in b and 'const last = sh.getLastRow();' in b),
    ('frontend_nanas_new',newc in c),
    ('backend_nanas_new',newb in b),
    ('cache_updated','absensi-gps-nanas-location-fix-20260930' in s),
]
for k,v in checks:
    print(('OK' if v else 'FAIL')+' - '+k)
if not all(v for _,v in checks):
    raise SystemExit('ERROR: validasi gagal')

cfg.write_text(c,encoding='utf-8')
be.write_text(b,encoding='utf-8')
sw.write_text(s,encoding='utf-8')

print('PATCH BERHASIL')
print('Nanas baru: -6.618490474658237, 106.78478377021241')
print('Radius: 10 meter')
