Absensi v1.9.6 - Checkout GPS Fix
- Absen pulang: timeout GPS presisi 45 detik.
- Jika gagal, retry otomatis 30 detik.
- Retry boleh memakai lokasi yang masih baru (maks. 60 detik).
- Absen masuk dan geofence 10 m tidak diubah.
