ABSENSI CS.FLOW — FIX SERVEREXECUTION + JOBDESK PULANG
5 Oktober 2026

Perubahan:
- Retry aman untuk "Server execution failed" / server sementara sibuk.
- Check-in tidak langsung macet bila pengecekan awal server gagal sementara.
- Checkout melakukan kirim + verifikasi + retry aman.
- Tambah input wajib "Jobdesk Pulang".
- Spreadsheet otomatis menambah kolom ke-23 "Jobdesk Pulang".
- Data lama tidak dihapus atau digeser.
- Kebandungan dan Nanas tetap radius 200 m.
- Versi tetap 1.9.9.
- Cache PWA/WebView diganti agar device mengambil frontend baru.

CARA PASANG
1. Upload ZIP ini ke root Codespaces.
2. Jalankan:
   unzip -o "Absensi_FIX_ServerExecution_JobdeskPulang.zip"
   python3 apply_fix_server_jobdesk.py

3. Script otomatis menjalankan test.
   Harus berakhir dengan:
   PATCH BERHASIL DAN TEST LULUS

4. Lalu:
   git status --short
   git add web/index.html web/sw.js backend/Code.gs tests/attendance.test.cjs
   git commit -m "Fix ServerExecution and add checkout jobdesk"
   git pull --rebase origin main
   git push origin main

Jangan force push. Jika muncul CONFLICT, berhenti dan kirim screenshot.

SETELAH PUSH
- Copy seluruh backend/Code.gs terbaru ke Google Apps Script.
- Save.
- Deploy -> Manage deployments -> Edit -> New version -> Deploy.
- Gunakan deployment /exec yang sama.

Spreadsheet tidak perlu diedit manual. Kolom "Jobdesk Pulang" akan dibuat otomatis saat backend baru dijalankan.

Setelah deploy:
- Force close APK/PWA pada device yang bermasalah.
- Buka lagi.
- Isi Jobdesk Pulang sebelum ABSEN PULANG.
