#!/usr/bin/env python3
from pathlib import Path
import subprocess

ROOT = Path.cwd()
INDEX = ROOT / "web" / "index.html"
BACKEND = ROOT / "backend" / "Code.gs"
SW = ROOT / "web" / "sw.js"
TESTS = ROOT / "tests" / "attendance.test.cjs"

for p in (INDEX, BACKEND, SW, TESTS):
    if not p.exists():
        raise SystemExit(f"ERROR: {p} tidak ditemukan. Jalankan dari root repo absensi-cross-devicev2.")

original = {p: p.read_text(encoding="utf-8") for p in (INDEX, BACKEND, SW, TESTS)}
index = original[INDEX]
backend = original[BACKEND]
sw = original[SW]
tests = original[TESTS]

def replace_once(text, old, new, label):
    if new in text:
        print(f"SKIP - {label} sudah terpasang")
        return text
    if old not in text:
        raise RuntimeError(f"Gagal menemukan blok untuk: {label}")
    print(f"OK   - {label}")
    return text.replace(old, new, 1)

try:
    index = replace_once(
        index,
        """      <div class="card">
        <h2>Detail Pekerjaan</h2>
        <div class="field">
          <label>Kerjaan hari ini</label>
          <textarea id="work" placeholder="Tuliskan pekerjaan yang dilakukan hari ini..." required></textarea>
        </div>
      </div>""",
        """      <div class="card">
        <h2>Detail Pekerjaan</h2>
        <div class="field">
          <label>Kerjaan hari ini</label>
          <textarea id="work" placeholder="Tuliskan pekerjaan yang dilakukan hari ini..." required></textarea>
        </div>
        <div class="field" style="margin-top:12px">
          <label>Jobdesk Pulang</label>
          <textarea id="outWork" placeholder="Tuliskan pekerjaan yang diselesaikan / serah terima sebelum pulang..." required></textarea>
          <div class="schedule-note">Wajib diisi sebelum ABSEN PULANG.</div>
        </div>
      </div>""",
        "input Jobdesk Pulang"
    )

    index = replace_once(
        index,
        """function queueCheckout(r,point){
  const previous=pendingCheckout();
  const item={endpoint:endpoint(),payload:{type:'checkout',requestId:previous?.payload.requestId||('out_'+Date.now()+'_'+Math.random().toString(36).slice(2)),record:{id:r.id,employee:r.employee,warehouse:r.warehouse,date:r.date,outGps:{...point}}}};
  const rows=pendingCheckouts().filter(x=>!(x.endpoint===item.endpoint&&sameAttendance(x.payload.record,r)));
  rows.push(item);
  localStorage.setItem(keyPendingCheckout,JSON.stringify(rows.slice(-20)));
  return item;
}""",
        """function queueCheckout(r,point,outWork){
  const previous=pendingCheckout();
  const item={endpoint:endpoint(),payload:{type:'checkout',requestId:previous?.payload.requestId||('out_'+Date.now()+'_'+Math.random().toString(36).slice(2)),record:{id:r.id,employee:r.employee,warehouse:r.warehouse,date:r.date,outGps:{...point},outWork:String(outWork||'').trim()}}};
  const rows=pendingCheckouts().filter(x=>!(x.endpoint===item.endpoint&&sameAttendance(x.payload.record,r)));
  rows.push(item);
  localStorage.setItem(keyPendingCheckout,JSON.stringify(rows.slice(-20)));
  return item;
}""",
        "payload checkout membawa Jobdesk Pulang"
    )

    index = replace_once(
        index,
        "function connectionError(message){const err=new Error(message);err.retryable=true;return err;}",
        """function connectionError(message){const err=new Error(message);err.retryable=true;return err;}
function serverResponseError(message){
  const text=String(message||'Server gagal.');
  if(/server\\s*execution|execution failed|server sedang sibuk|temporar|timeout|timed out|service unavailable|internal error|try again|quota|too many|koneksi|belum merespons/i.test(text)) return connectionError(text);
  return new Error(text);
}""",
        "klasifikasi error server retryable"
    )

    index = replace_once(
        index,
        "        if(!data?.ok) throw new Error(data?.error||'Status server gagal.');",
        "        if(!data?.ok) throw serverResponseError(data?.error||'Status server gagal.');",
        "retry ServerExecution failed saat baca server"
    )

    if "checkoutWork:r.checkoutWork||r.outWork||existing.checkoutWork||existing.outWork||''," not in index:
        index = replace_once(
            index,
            "    work:r.work||existing.work||'',\n    source:'server'",
            "    work:r.work||existing.work||'',\n    checkoutWork:r.checkoutWork||r.outWork||existing.checkoutWork||existing.outWork||'',\n    source:'server'",
            "merge Jobdesk Pulang dari server"
        )

    index = replace_once(
        index,
        "      if(!result?.ok) throw new Error(result?.error||'Server menolak absen pulang.');",
        "      if(!result?.ok) throw serverResponseError(result?.error||'Server menolak absen pulang.');",
        "retry penolakan sementara checkout"
    )

    old_verify = """async function verifyCheckout(item){
  const r=item.payload.record;
  for(let i=0;i<3;i++){
    await delay(i===0?700:1500);
    try{
      const data=await jsonp({action:'writeStatus',requestId:item.payload.requestId,employee:r.employee,warehouse:r.warehouse});
      // Old backends do not implement writeStatus. Verify against today's row instead.
      if(!data?.ok) break;
      if(data.pending) continue;
      const result=data.result;
      if(!result?.ok) throw serverResponseError(result?.error||'Server menolak absen pulang.');
      if(result.record&&sameAttendance(result.record,r)&&(result.record.out||result.record.outLocal)) return result.record;
      throw new Error('Konfirmasi server tidak cocok dengan permintaan absen pulang.');
    }catch(err){if(!err.retryable) throw err;}
  }
  const result=await verifyToday(2,true);
  return result&&sameAttendance(result,r)?result:null;
}"""

    new_verify = """async function verifyCheckout(item){
  const r=item.payload.record;
  let lastError=null;
  for(let i=0;i<3;i++){
    await delay(i===0?700:1500);
    try{
      const data=await jsonp({action:'writeStatus',requestId:item.payload.requestId,employee:r.employee,warehouse:r.warehouse});
      // Old backends do not implement writeStatus. Verify against today's row instead.
      if(!data?.ok) break;
      if(data.pending) continue;
      const result=data.result;
      if(!result?.ok) throw serverResponseError(result?.error||'Server menolak absen pulang.');
      if(result.record&&sameAttendance(result.record,r)&&(result.record.out||result.record.outLocal)) return result.record;
      throw new Error('Konfirmasi server tidak cocok dengan permintaan absen pulang.');
    }catch(err){
      if(!err.retryable) throw err;
      lastError=err;
    }
  }
  const result=await verifyToday(2,true);
  if(result&&sameAttendance(result,r)) return result;
  if(lastError) throw lastError;
  return null;
}

async function sendCheckinReliable(record){
  const payload={type:'checkin',record};
  let lastError=null;
  for(let cycle=0;cycle<2;cycle++){
    try{await sendWrite(payload);}
    catch(err){
      if(!err.retryable) throw err;
      lastError=err;
    }
    const verified=await verifyToday(cycle===0?5:4);
    if(verified) return verified;
    if(cycle===0){
      attendanceStatus('Server lambat. Memastikan data sebelum mengirim sekali lagi...');
      await delay(1500);
    }
  }
  if(lastError) throw lastError;
  return null;
}

async function sendCheckoutReliable(item){
  let lastError=null;
  for(let cycle=0;cycle<3;cycle++){
    try{await sendWrite(item.payload);}
    catch(err){
      if(!err.retryable) throw err;
      lastError=err;
    }
    try{
      const verified=await verifyCheckout(item);
      if(verified) return verified;
    }catch(err){
      if(!err.retryable) throw err;
      lastError=err;
    }
    if(cycle<2){
      attendanceStatus('Server belum mengonfirmasi. Mencoba ulang '+(cycle+2)+'/3...');
      await delay(1500*(cycle+1));
    }
  }
  if(lastError) throw lastError;
  return null;
}"""

    if "async function sendCheckoutReliable(item)" not in index:
        if old_verify not in index:
            raise RuntimeError("Gagal menemukan verifyCheckout")
        index = index.replace(old_verify, new_verify, 1)
        print("OK   - retry otomatis check-in/checkout")

    index = replace_once(
        index,
        """  if(endpoint()){
    const existing=await serverToday();
    if(existing){mergeServerToday(existing);return alert((existing.out||existing.outLocal)?'Hari ini sudah absen dan sudah pulang.':'Hari ini sudah absen masuk.');}
  }""",
        """  if(endpoint()){
    try{
      const existing=await serverToday({attempts:3});
      if(existing){mergeServerToday(existing);return alert((existing.out||existing.outLocal)?'Hari ini sudah absen dan sudah pulang.':'Hari ini sudah absen masuk.');}
    }catch(err){
      if(!err.retryable) throw err;
      $('serverBadge').textContent='Server lambat';
      $('serverBadge').className='pill warn';
      $('syncState').textContent='Server sementara tidak terbaca. Absensi tetap dilanjutkan dan akan diverifikasi setelah pengiriman.';
    }
  }""",
        "pre-check check-in tetap lanjut saat server error sementara"
    )

    index = replace_once(
        index,
        """    if(endpoint()){
      await sendWrite({type:'checkin',record});
      const verified=await verifyToday();
      if(!verified) throw new Error('Data tersimpan lokal, tetapi server belum mengonfirmasi. Tekan Absen Masuk lagi untuk memeriksa dan mencoba ulang.');
      mergeServerToday(verified);""",
        """    if(endpoint()){
      const verified=await sendCheckinReliable(record);
      if(!verified) throw new Error('Data tersimpan lokal, tetapi server belum mengonfirmasi. Tekan Absen Masuk lagi untuk memeriksa dan mencoba ulang.');
      mergeServerToday(verified);""",
        "check-in retry aman"
    )

    index = replace_once(
        index,
        """    if(!r){attendanceStatus('Absen masuk hari ini belum ditemukan.','bad');return alert('Belum ada absen masuk hari ini.');}
    if(r.out||r.outLocal){attendanceStatus('Absen pulang sudah terkonfirmasi.','ok');return alert('Absen pulang sudah tersimpan.');}

    attendanceStatus('Mengambil lokasi untuk absen pulang...');""",
        """    if(!r){attendanceStatus('Absen masuk hari ini belum ditemukan.','bad');return alert('Belum ada absen masuk hari ini.');}
    if(r.out||r.outLocal){attendanceStatus('Absen pulang sudah terkonfirmasi.','ok');return alert('Absen pulang sudah tersimpan.');}

    const pending=pendingCheckout();
    const outWork=String($('outWork').value||pending?.payload?.record?.outWork||'').trim();
    if(!outWork) return alert('Jobdesk Pulang wajib diisi sebelum Absen Pulang.');

    attendanceStatus('Mengambil lokasi untuk absen pulang...');""",
        "Jobdesk Pulang wajib"
    )

    index = replace_once(index, "      const item=queueCheckout(r,gps);", "      const item=queueCheckout(r,gps,outWork);", "queue jobdesk pulang")

    index = replace_once(
        index,
        """      attendanceStatus('Mengirim absen pulang. Mohon tunggu...');
      try{await sendWrite(item.payload);}catch(err){if(!err.retryable) throw err;}
      attendanceStatus('Memeriksa hasil penyimpanan di server. Mohon tunggu...');
      const verified=await verifyCheckout(item);""",
        """      attendanceStatus('Mengirim absen pulang. Mohon tunggu...');
      const verified=await sendCheckoutReliable(item);""",
        "checkout retry otomatis"
    )

    index = replace_once(
        index,
        """      mergeServerToday(verified);
      attendanceStatus('Absen pulang terkonfirmasi di server.','ok');
      alert('Absen pulang terverifikasi. Lembur = '+Number(verified.overtime||0).toFixed(2)+' jam.');""",
        """      mergeServerToday(verified);
      $('outWork').value='';
      attendanceStatus('Absen pulang terkonfirmasi di server.','ok');
      alert('Absen pulang terverifikasi. Lembur = '+Number(verified.overtime||0).toFixed(2)+' jam.');""",
        "bersihkan input jobdesk pulang"
    )

    index = replace_once(
        index,
        "      r={...r,out:now.toISOString(),outLocal:now.toLocaleTimeString('id-ID',{hour12:false,timeZone:'Asia/Jakarta'}),outGps:{...gps}};",
        "      r={...r,out:now.toISOString(),outLocal:now.toLocaleTimeString('id-ID',{hour12:false,timeZone:'Asia/Jakarta'}),outGps:{...gps},outWork,checkoutWork:outWork};",
        "mode lokal simpan jobdesk pulang"
    )

    index = replace_once(
        index,
        """      '<div style="margin-top:5px">'+escapeHtml(r.work||'Tidak ada detail pekerjaan')+'</div>'+
      '</div>';""",
        """      '<div style="margin-top:5px"><b>Jobdesk masuk:</b> '+escapeHtml(r.work||'Tidak ada detail pekerjaan')+'</div>'+
      '<div style="margin-top:5px"><b>Jobdesk pulang:</b> '+escapeHtml(r.checkoutWork||r.outWork||'-')+'</div>'+
      '</div>';""",
        "riwayat tampilkan jobdesk pulang"
    )

    index = replace_once(
        index,
        """function render(){
  renderHistory();
  $('version').textContent=CFG.APP_VERSION||'1.9.9';
  if(!attendanceBusy&&pendingCheckout()) attendanceStatus('Ada permintaan pulang yang belum terkonfirmasi. Tekan Absen Pulang untuk mencoba kembali.');""",
        """function render(){
  renderHistory();
  $('version').textContent=CFG.APP_VERSION||'1.9.9';
  const pending=pendingCheckout();
  if(pending&&$('outWork')&&!$('outWork').value) $('outWork').value=String(pending.payload.record.outWork||'');
  if(!attendanceBusy&&pending) attendanceStatus('Ada permintaan pulang yang belum terkonfirmasi. Tekan Absen Pulang untuk mencoba kembali.');""",
        "pending checkout mempertahankan jobdesk"
    )

    backend = replace_once(
        backend,
        """  'Host','Status','Dibuat','Diubah','Gudang'
];""",
        """  'Host','Status','Dibuat','Diubah','Gudang','Jobdesk Pulang'
];""",
        "header Jobdesk Pulang"
    )

    backend = replace_once(backend, "        capabilities: {writeStatus:true},", "        capabilities: {writeStatus:true,checkoutWork:true},", "health capability")

    backend = replace_once(
        backend,
        """    String(r.work || '').trim(), '', '', '', '', 0,
    hostLabel_(), 'MASUK', serverNow, serverNow, warehouse
  ]);""",
        """    String(r.work || '').trim(), '', '', '', '', 0,
    hostLabel_(), 'MASUK', serverNow, serverNow, warehouse, ''
  ]);""",
        "check-in kolom jobdesk pulang kosong"
    )

    backend = replace_once(
        backend,
        """  if (existing.outLocal) return {ok:true,duplicate:true,record:existing};

  const outLocal = format_(serverNow, 'HH:mm:ss');
  const normalOut = getProp_('NORMAL_OUT', DEFAULT_NORMAL_OUT);
  const overtime = overtimeHours_(existing.inLocal, outLocal, normalOut);

  sh.getRange(row,13,1,9).setValues([[
    outLocal,
    val_(r.outGps,'lat'), val_(r.outGps,'lon'), val_(r.outGps,'accuracy'),
    overtime,
    hostLabel_(), 'PULANG',
    sh.getRange(row,20).getValue() || serverNow,
    serverNow
  ]]);""",
        """  if (existing.outLocal) return {ok:true,duplicate:true,record:existing};

  const checkoutWork = String(r.outWork || r.checkoutWork || '').trim().slice(0,1000);
  if (!checkoutWork) throw new Error('Jobdesk Pulang wajib diisi');

  const outLocal = format_(serverNow, 'HH:mm:ss');
  const normalOut = getProp_('NORMAL_OUT', DEFAULT_NORMAL_OUT);
  const overtime = overtimeHours_(existing.inLocal, outLocal, normalOut);

  sh.getRange(row,13,1,11).setValues([[
    outLocal,
    val_(r.outGps,'lat'), val_(r.outGps,'lon'), val_(r.outGps,'accuracy'),
    overtime,
    hostLabel_(), 'PULANG',
    sh.getRange(row,20).getValue() || serverNow,
    serverNow,
    existing.warehouse,
    checkoutWork
  ]]);""",
        "backend simpan Jobdesk Pulang"
    )

    backend = replace_once(
        backend,
        """function ensureHeader_(sh) {
  const last = sh.getLastRow();
  const legacyHeaders = HEADERS.slice(0,21);

  if (last === 0) {
    sh.getRange(1,1,1,HEADERS.length).setValues([HEADERS]);
    return;
  }

  const legacyCurrent = sh.getRange(1,1,1,legacyHeaders.length).getDisplayValues()[0];
  const legacySame = legacyHeaders.every((h,i) => String(legacyCurrent[i] || '') === h);
  const currentWarehouseHeader = String(sh.getRange(1,22).getDisplayValue() || '');

  if (legacySame && currentWarehouseHeader === 'Gudang') return;

  if (legacySame && !currentWarehouseHeader) {
    sh.getRange(1,22).setValue('Gudang');
    return;
  }

  if (last <= 1) {
    sh.getRange(1,1,1,Math.max(sh.getLastColumn(),HEADERS.length)).clearContent();
    sh.getRange(1,1,1,HEADERS.length).setValues([HEADERS]);
    return;
  }

  throw new Error('Struktur sheet tidak dikenali. Backup data lalu periksa header sheet Absensi.');
}""",
        """function ensureHeader_(sh) {
  const last = sh.getLastRow();
  const legacyHeaders = HEADERS.slice(0,21);

  if (last === 0) {
    sh.getRange(1,1,1,HEADERS.length).setValues([HEADERS]);
    return;
  }

  const legacyCurrent = sh.getRange(1,1,1,legacyHeaders.length).getDisplayValues()[0];
  const legacySame = legacyHeaders.every((h,i) => String(legacyCurrent[i] || '') === h);
  const currentWarehouseHeader = String(sh.getRange(1,22).getDisplayValue() || '');
  const currentCheckoutWorkHeader = String(sh.getRange(1,23).getDisplayValue() || '');

  if (legacySame && currentWarehouseHeader === 'Gudang' && currentCheckoutWorkHeader === 'Jobdesk Pulang') return;

  if (legacySame && currentWarehouseHeader === 'Gudang' && !currentCheckoutWorkHeader) {
    sh.getRange(1,23).setValue('Jobdesk Pulang');
    return;
  }

  if (legacySame && !currentWarehouseHeader) {
    sh.getRange(1,22,1,2).setValues([['Gudang','Jobdesk Pulang']]);
    return;
  }

  if (last <= 1) {
    sh.getRange(1,1,1,Math.max(sh.getLastColumn(),HEADERS.length)).clearContent();
    sh.getRange(1,1,1,HEADERS.length).setValues([HEADERS]);
    return;
  }

  throw new Error('Struktur sheet tidak dikenali. Backup data lalu periksa header sheet Absensi.');
}""",
        "migrasi header otomatis"
    )

    backend = replace_once(
        backend,
        """    work:String(v[11]||''),
    outLocal:v[12] instanceof Date ? format_(v[12], 'HH:mm:ss') : String(v[12]||''),
    overtime:Number(v[16])||0,
    status:String(v[18]||'')""",
        """    work:String(v[11]||''),
    outLocal:v[12] instanceof Date ? format_(v[12], 'HH:mm:ss') : String(v[12]||''),
    overtime:Number(v[16])||0,
    status:String(v[18]||''),
    checkoutWork:String(v[22]||'')""",
        "API today kirim jobdesk pulang"
    )

    sw_lines = sw.splitlines()
    if not sw_lines or not sw_lines[0].startswith("const CACHE = "):
        raise RuntimeError("CACHE service worker tidak ditemukan")
    sw_lines[0] = "const CACHE = 'absensi-gps-v1.9.9-server-jobdesk-pulang-20261005';"
    sw = "\n".join(sw_lines) + ("\n" if original[SW].endswith("\n") else "")
    print("OK   - cache PWA/WebView diperbarui")

    tests = replace_once(
        tests,
        "const baseRecord = () => ({id:'in-1',employee:'Mas Suryo',warehouse:'KEBANDUNGAN',date:'2026-10-01',division:'GUDANG',inLocal:'09:00:00',out:null,outLocal:null,source:'server',inPhoto:'data:image/jpeg;base64,'+'X'.repeat(100000)});",
        "const baseRecord = () => ({id:'in-1',employee:'Mas Suryo',warehouse:'KEBANDUNGAN',date:'2026-10-01',division:'GUDANG',inLocal:'09:00:00',out:null,outLocal:null,source:'server',work:'Masuk',checkoutWork:'',inPhoto:'data:image/jpeg;base64,'+'X'.repeat(100000)});",
        "test baseRecord"
    )
    tests = replace_once(tests, "const confirmedRecord = () => ({...baseRecord(),outLocal:'22:02:00',overtime:4.53});", "const confirmedRecord = () => ({...baseRecord(),outLocal:'22:02:00',overtime:4.53,checkoutWork:'Packing selesai'});", "test confirmedRecord")
    tests = replace_once(
        tests,
        "document:{getElementById:element,createElement:()=>({remove(){this.removed=true;}}),head:{appendChild:s=>scripts.push(s)},querySelectorAll:()=>[element('checkIn'),element('checkOut'),element('employee'),element('division')]},",
        "document:{getElementById:element,createElement:()=>({remove(){this.removed=true;}}),head:{appendChild:s=>scripts.push(s)},querySelectorAll:()=>[element('checkIn'),element('checkOut'),element('employee'),element('division'),element('outWork')]},",
        "test DOM outWork"
    )
    tests = replace_once(tests, "  element('employee').value='Mas Suryo';element('division').value='GUDANG';", "  element('employee').value='Mas Suryo';element('division').value='GUDANG';element('outWork').value='Packing selesai';", "test default jobdesk")
    tests = replace_once(tests, "  assert.deepEqual(Object.keys(payload.record).sort(),['date','employee','id','outGps','warehouse']);", "  assert.deepEqual(Object.keys(payload.record).sort(),['date','employee','id','outGps','outWork','warehouse']);", "test payload checkout")

    if "checkout requires Jobdesk Pulang before GPS or write" not in tests:
        marker = "test('unconfirmed checkout survives reload, retains the request id, and never creates false success',async()=>{"
        insert = "test('checkout requires Jobdesk Pulang before GPS or write',async()=>{\\n  const b=browser();b.ctx.saveRecords([baseRecord()]);b.element('outWork').value='';let writes=0;\\n  b.ctx.fetch=async()=>{writes++;return {type:'opaque'};};\\n  await b.ctx.checkOut();assert.equal(writes,0);assert.match(b.alerts.at(-1),/Jobdesk Pulang wajib/);\\n});\\n\\n"
        if marker not in tests:
            raise RuntimeError("Marker test checkout tidak ditemukan")
        tests = tests.replace(marker, insert + marker, 1)
        print("OK   - test jobdesk pulang wajib")

    if "today retries Apps Script Server execution failed responses" not in tests:
        marker = "test('checkout bypasses the blocking read, sends no check-in photo, and confirms before marking done',async()=>{"
        insert = "test('today retries Apps Script Server execution failed responses',async()=>{\\n  const b=browser();let reads=0;\\n  b.ctx.jsonp=async()=>{reads++;return reads===1?{ok:false,error:'Server execution failed'}:{ok:true,record:baseRecord()};};\\n  const r=await b.ctx.serverToday();assert.equal(r.id,'in-1');assert.equal(reads,2);\\n});\\n\\n"
        if marker not in tests:
            raise RuntimeError("Marker test server retry tidak ditemukan")
        tests = tests.replace(marker, insert + marker, 1)
        print("OK   - test ServerExecution retry")

    tests = replace_once(tests, "    getLastRow:()=>rows.length,getLastColumn:()=>22,", "    getLastRow:()=>rows.length,getLastColumn:()=>23,", "mock 23 kolom")
    tests = replace_once(
        tests,
        "const headers=['ID','Karyawan','Divisi','Tanggal','Jam Masuk','Jadwal Masuk','Telat Menit','Lat Masuk','Lon Masuk','Akurasi Masuk','Foto','Pekerjaan','Jam Pulang','Lat Pulang','Lon Pulang','Akurasi Pulang','Lembur Jam','Host','Status','Dibuat','Diubah','Gudang'];",
        "const headers=['ID','Karyawan','Divisi','Tanggal','Jam Masuk','Jadwal Masuk','Telat Menit','Lat Masuk','Lon Masuk','Akurasi Masuk','Foto','Pekerjaan','Jam Pulang','Lat Pulang','Lon Pulang','Akurasi Pulang','Lembur Jam','Host','Status','Dibuat','Diubah','Gudang','Jobdesk Pulang'];",
        "test header 23"
    )
    tests = replace_once(
        tests,
        "for(let i=0;i<count;i++) rows.push([i===count-1?'in-1':'old-'+i,i===count-1?'Mas   Suryo':'Other','GUDANG',i===count-1?new Clock('2026-10-01T02:00:00Z'):'2026-09-30','09:00:00','09:00',0,0,0,5,'photo','work','','','','',0,'host','MASUK',new Clock(),new Clock(),'KEBANDUNGAN']);",
        "for(let i=0;i<count;i++) rows.push([i===count-1?'in-1':'old-'+i,i===count-1?'Mas   Suryo':'Other','GUDANG',i===count-1?new Clock('2026-10-01T02:00:00Z'):'2026-09-30','09:00:00','09:00',0,0,0,5,'photo','work','','','','',0,'host','MASUK',new Clock(),new Clock(),'KEBANDUNGAN','']);",
        "test row 23 kolom"
    )
    tests = replace_once(tests, "const outPayload=()=>({id:'in-1',employee:'mas suryo',warehouse:'KEBANDUNGAN',date:'2026-10-01',outGps:{lat:-6.633483,lon:106.775966,accuracy:5}});", "const outPayload=()=>({id:'in-1',employee:'mas suryo',warehouse:'KEBANDUNGAN',date:'2026-10-01',outGps:{lat:-6.633483,lon:106.775966,accuracy:5},outWork:'Packing selesai'});", "test backend outWork")
    tests = replace_once(tests, "  assert.equal(status.result.record.outLocal,'22:02:00');", "  assert.equal(status.result.record.outLocal,'22:02:00');assert.equal(rows[1][22],'Packing selesai');", "test jobdesk tersimpan")
    tests = replace_once(tests, "  for(const change of [{employee:'Other'},{warehouse:'CM'},{outGps:{lat:91,lon:0}},{outGps:{lat:null,lon:0}}]){", "  for(const change of [{employee:'Other'},{warehouse:'CM'},{outGps:{lat:91,lon:0}},{outGps:{lat:null,lon:0}},{outWork:''}]){", "test backend tolak outWork kosong")

    config = (ROOT / "web" / "config.js").read_text(encoding="utf-8")
    checks = [
        ("Kebandungan frontend 200m", "RADIUS_M:200" in config and "LAT:-6.633483, LON:106.775966" in config),
        ("Nanas frontend 200m", "LAT:-6.618490474658237, LON:106.78478377021241, RADIUS_M:200" in config),
        ("Kebandungan backend 200m", "lat:-6.633483, lon:106.775966, radiusM:200" in backend),
        ("Nanas backend 200m", "lat:-6.618490474658237, lon:106.78478377021241, radiusM:200" in backend),
        ("versi tetap 1.9.9", "const APP_VERSION = '1.9.9';" in backend),
        ("frontend Jobdesk Pulang", 'id="outWork"' in index),
        ("backend Jobdesk Pulang", "'Jobdesk Pulang'" in backend and "checkoutWork" in backend),
        ("retry server", "serverResponseError" in index and "sendCheckoutReliable" in index),
    ]
    for label, ok in checks:
        print(("OK   - " if ok else "FAIL - ") + label)
    if not all(ok for _, ok in checks):
        raise RuntimeError("Validasi patch gagal")

    INDEX.write_text(index, encoding="utf-8")
    BACKEND.write_text(backend, encoding="utf-8")
    SW.write_text(sw, encoding="utf-8")
    TESTS.write_text(tests, encoding="utf-8")

    print("\nMenjalankan test...")
    result = subprocess.run(["node", "--test", str(TESTS)], cwd=ROOT)
    if result.returncode != 0:
        print("\nTEST GAGAL - file dikembalikan ke kondisi sebelum patch.")
        for p, content in original.items():
            p.write_text(content, encoding="utf-8")
        raise SystemExit(result.returncode)

    print("\nPATCH BERHASIL DAN TEST LULUS.")
    print("- ServerExecution failed: retry aman aktif")
    print("- Jobdesk Pulang: wajib dan tersimpan ke spreadsheet kolom 23")
    print("- Kebandungan/Nanas: tetap 200 meter")
    print("- Versi: tetap 1.9.9")

except Exception as e:
    print(f"\nERROR: {e}")
    raise SystemExit(1)
