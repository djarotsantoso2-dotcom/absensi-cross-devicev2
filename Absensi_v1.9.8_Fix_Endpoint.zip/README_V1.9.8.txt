ABSENSI v1.9.8 - FIX ENDPOINT DEVICE
=====================================
Perubahan:
- APP_VERSION menjadi 1.9.8.
- Endpoint Apps Script lama yang tersimpan di localStorage device dibersihkan otomatis.
- Setelah dibersihkan, fungsi endpoint() di index.html otomatis jatuh ke GAS_ENDPOINT resmi dari config.js.
- Cache jadwal lama yang terbaca sebagai tanggal tahun 1899 dinormalisasi:
  ADMIN -> 08:00
  PACKING/GUDANG -> 09:00
- Dashboard tetap dihapus.
- Geofence tidak berubah.
- Apps Script / Google Sheets tidak perlu diubah.
- Service worker cache dibump agar device mengambil config baru.

File yang perlu dipush:
web/config.js
web/sw.js
