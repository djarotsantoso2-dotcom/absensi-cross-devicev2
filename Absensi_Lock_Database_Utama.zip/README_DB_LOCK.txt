ABSENSI - LOCK DATABASE UTAMA

Database utama:
Database Absensi Kamera GPS
ID: 1yELZY2kInp3AiDx7jvQBpAlgWF238oGN-qfZlETS0YQ

Patch ini hanya mengubah backend/Code.gs:
1. Menambahkan PRIMARY_SPREADSHEET_ID.
2. getSheet_() tidak lagi membaca Script Property SPREADSHEET_ID.
3. Backend selalu membuka database utama.

CARA:
1. Upload ZIP ke root repo Codespaces.
2. unzip -o "Absensi_Lock_Database_Utama.zip"
3. bash apply_db_lock.sh
4. git add backend/Code.gs
5. git commit -m "Lock attendance backend to primary spreadsheet"
6. git push origin main

SETELAH PUSH:
- Buka backend/Code.gs di GitHub/Codespaces.
- Copy seluruh isinya.
- Paste menggantikan seluruh Code.gs di Google Apps Script.
- Save.
- Deploy > Manage deployments > Edit > New version > Deploy.
- Gunakan deployment Web App yang sama.

CATATAN:
Data lama yang sudah terlanjur masuk ke spreadsheet "Untitled spreadsheet"
tidak otomatis dipindahkan ke database utama.
