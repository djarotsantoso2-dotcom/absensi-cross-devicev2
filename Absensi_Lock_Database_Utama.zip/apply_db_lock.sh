#!/usr/bin/env bash
set -euo pipefail

FILE="backend/Code.gs"
DB_ID="1yELZY2kInp3AiDx7jvQBpAlgWF238oGN-qfZlETS0YQ"

if [ ! -f "$FILE" ]; then
  echo "ERROR: $FILE tidak ditemukan. Jalankan dari root repo absensi-cross-devicev2."
  exit 1
fi

cp "$FILE" "${FILE}.bak-before-db-lock"

python3 - <<'PY'
from pathlib import Path

p = Path("backend/Code.gs")
s = p.read_text(encoding="utf-8")

const_old = "const DEFAULT_NORMAL_OUT = '17:30';"
const_new = """const DEFAULT_NORMAL_OUT = '17:30';
const PRIMARY_SPREADSHEET_ID = '1yELZY2kInp3AiDx7jvQBpAlgWF238oGN-qfZlETS0YQ';"""

if "const PRIMARY_SPREADSHEET_ID =" not in s:
    if const_old not in s:
        raise SystemExit("GAGAL: posisi DEFAULT_NORMAL_OUT tidak ditemukan.")
    s = s.replace(const_old, const_new, 1)

old = """function getSheet_() {
  const spreadsheetId = getProp_('SPREADSHEET_ID','');
  if (!spreadsheetId) throw new Error('Script Property SPREADSHEET_ID belum diisi');

  const ss = SpreadsheetApp.openById(spreadsheetId);"""

new = """function getSheet_() {
  const ss = SpreadsheetApp.openById(PRIMARY_SPREADSHEET_ID);"""

if old in s:
    s = s.replace(old, new, 1)
elif "SpreadsheetApp.openById(PRIMARY_SPREADSHEET_ID)" not in s:
    raise SystemExit("GAGAL: blok getSheet_ lama tidak ditemukan. Tidak ada perubahan dibuat.")

p.write_text(s, encoding="utf-8")
print("OK: backend/Code.gs sekarang dikunci ke database utama.")
print("Database:", "1yELZY2kInp3AiDx7jvQBpAlgWF238oGN-qfZlETS0YQ")
PY

echo
echo "Cek perubahan:"
git diff -- backend/Code.gs
